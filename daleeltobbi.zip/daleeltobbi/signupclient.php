<?php
include 'config.php';

define('MAX_LENGTH', 255);

function clean($input, $maxlength)
{
    $input = substr($input, 0, $maxlength);
    $input = escapeshellcmd($input);
    $input = htmlspecialchars($input, ENT_QUOTES);
    return $input;
}

$errors = array();

if (isset($_POST["name"], $_POST["email"], $_POST["password"], $_POST["confirmPassword"])) {

    $name = clean($_POST["name"], MAX_LENGTH);
    $email = clean($_POST["email"], MAX_LENGTH);
    $password = clean($_POST["password"], MAX_LENGTH);
    $confirmPassword = clean($_POST["confirmPassword"], MAX_LENGTH);

    if ($password !== $confirmPassword) {
        $errors[] = " Passwords do not match.";
    }

    $passwordPattern = '/^(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*])[a-zA-Z\d!@#$%^&*]{8,}$/';
    if (!preg_match($passwordPattern, $password)) {
        $errors[] = " Password must meet security conditions - 8 characters minimum, 1 uppercase letter, 1 number, and 1 symbol.";
    }

    $checkEmailQuery = "SELECT * FROM client_acc WHERE email = '$email'";
    $resultCheckEmail = mysqli_query($con, $checkEmailQuery);

    if (mysqli_num_rows($resultCheckEmail) > 0) {
        $errors[] = " Email already exists.";
    }

    if (empty($errors)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        $insertQuery = "INSERT INTO client_acc (name, email, password) VALUES ('$name', '$email', '$hashed_password')";
        $resultInsert = mysqli_query($con, $insertQuery);

        if ($resultInsert) {
            echo '<script>alert("User registered successfully."); window.location.replace("loginclient.html");</script>';
            exit();
        } else {
            $errors[] = "Error:" . mysqli_error($con);
        }
    }
} else {
    $errors[] = " Invalid request";
}

// Display errors using JavaScript
if (!empty($errors)) {
    echo '<script>alert("' . implode('\n', $errors) . '");</script>';
}

mysqli_close($con);
?>
